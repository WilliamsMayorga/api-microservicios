package com.ideasconnections.microservicios.app.usuarios.microserviciosusuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
